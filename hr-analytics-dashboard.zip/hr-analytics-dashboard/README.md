# 📊 HR Analytics Dashboard

An interactive web app that turns a raw employee Excel file into HR analytics, attrition risk predictions, and a downloadable executive report — built as a portfolio project for the Master of Business Analytics program at Macquarie University.

**[🔗 Live demo](#)** — replace this link once deployed to Streamlit Community Cloud (see Deployment below)

![Python](https://img.shields.io/badge/Python-3.10+-blue) ![Streamlit](https://img.shields.io/badge/Streamlit-1.38-red) ![License](https://img.shields.io/badge/License-MIT-green)

---

## Why this project

HR teams routinely sit on rich employee data (tenure, salary, engagement, performance) but lack a quick way to turn it into decision-ready insight. This app simulates a lightweight internal analytics tool: upload a workforce dataset, pick the questions you care about (headcount, attrition, pay equity, who's at risk of leaving), and export a client-ready PPTX report in seconds.

It demonstrates an end-to-end analytics workflow: data ingestion → exploratory analysis → predictive modelling → automated reporting — the core loop of a business analyst's job.

## Features

- **Upload any employee Excel file** (or use the included synthetic sample dataset of 400 employees)
- **12 descriptive analytics**, selectable on demand:
  - Headcount by department / location
  - Attrition rate overall, by department, and by tenure band
  - Salary distribution, salary heatmap by department & level, gender pay gap
  - Engagement vs. attrition, performance distribution
  - Diversity snapshot, age distribution
- **Predictive attrition model** — a Random Forest classifier trained live on the uploaded data that:
  - Scores every employee's probability of leaving
  - Ranks the top drivers of attrition (feature importance)
  - Surfaces the 10 employees at highest risk
- **One-click export** — every chart downloads as a standalone JPG, or bundle your full selection into a branded PPTX deck with auto-generated insight captions

## Tech stack

| Layer | Tools |
|---|---|
| App / UI | Streamlit |
| Data handling | pandas, openpyxl |
| Visualization | matplotlib, seaborn |
| Predictive modelling | scikit-learn (Random Forest) |
| Report export | python-pptx |

## Project structure

```
hr-analytics-dashboard/
├── app.py              # Streamlit UI — main entry point
├── analytics.py        # Descriptive analytics & chart functions
├── predictive.py        # Attrition risk model (Random Forest)
├── export_utils.py     # JPG / PPTX export logic
├── sample_data.py       # Generates the synthetic demo dataset
├── sample_hr_data.xlsx  # Pre-generated 400-employee demo dataset
├── requirements.txt
└── README.md
```

## Running locally

```bash
git clone https://github.com/<your-username>/hr-analytics-dashboard.git
cd hr-analytics-dashboard
pip install -r requirements.txt
streamlit run app.py
```

Then open `http://localhost:8501`. Either upload your own Excel file or tick "Use sample dataset" in the sidebar to try it instantly.

### Expected input format

Your Excel file should contain one row per employee with these columns:

`Department, JobLevel, Age, Gender, Location, Education, TenureYears, Salary, PerformanceRating, EngagementScore, OvertimeHoursMonth, DistanceFromOfficeKm, YearsSinceLastPromotion, TrainingHoursYear, Attrition`

Run `python sample_data.py` to regenerate `sample_hr_data.xlsx` as a reference template.

## Deployment

This app is ready to deploy for free on [Streamlit Community Cloud](https://streamlit.io/cloud):
1. Push this repo to GitHub
2. Go to share.streamlit.io → New app → point it at `app.py`
3. Share the resulting public link on your resume/LinkedIn

## What I'd extend next

- Allow column mapping for arbitrary HR datasets instead of fixed column names
- Add a what-if simulator (e.g. "what if we raised salary 5%, how does predicted risk change?")
- Swap Random Forest for a tuned gradient boosting model with cross-validation
- Add authentication for multi-tenant use (different companies' data isolated)

## Author

Abiyad — Master of Business Analytics, Macquarie University.
Built as a portfolio project to demonstrate applied analytics, predictive modelling, and product thinking.

"""
Generates a realistic synthetic HR dataset and saves it as an Excel file.
Run this once to create sample_hr_data.xlsx for demoing the dashboard.
"""

import numpy as np
import pandas as pd

np.random.seed(42)

N = 400

departments = ["Sales", "Engineering", "Marketing", "HR", "Finance", "Operations", "Customer Support"]
job_levels = ["Junior", "Mid", "Senior", "Lead", "Manager"]
locations = ["Sydney", "Melbourne", "Brisbane", "Perth", "Remote"]
genders = ["Male", "Female", "Non-binary"]
education = ["Bachelor's", "Master's", "PhD", "Diploma"]

dept_salary_base = {
    "Sales": 75000, "Engineering": 105000, "Marketing": 80000,
    "HR": 70000, "Finance": 90000, "Operations": 72000, "Customer Support": 60000
}
level_multiplier = {"Junior": 0.75, "Mid": 1.0, "Senior": 1.3, "Lead": 1.55, "Manager": 1.9}

rows = []
for i in range(1, N + 1):
    dept = np.random.choice(departments, p=[0.22, 0.2, 0.13, 0.08, 0.12, 0.15, 0.10])
    level = np.random.choice(job_levels, p=[0.30, 0.30, 0.20, 0.12, 0.08])
    tenure_years = round(np.random.exponential(scale=3.2), 1)
    tenure_years = min(tenure_years, 22)
    age = int(np.clip(np.random.normal(34, 8), 21, 62))
    gender = np.random.choice(genders, p=[0.52, 0.46, 0.02])
    location = np.random.choice(locations, p=[0.35, 0.25, 0.12, 0.1, 0.18])
    edu = np.random.choice(education, p=[0.45, 0.35, 0.07, 0.13])

    base = dept_salary_base[dept] * level_multiplier[level]
    salary = round(np.random.normal(base, base * 0.08), -2)

    perf_rating = int(np.clip(np.random.normal(3.4, 0.8), 1, 5))
    engagement_score = int(np.clip(np.random.normal(70, 15), 10, 100))
    overtime_hours_month = round(max(0, np.random.normal(8, 6)), 1)
    distance_km = round(np.random.exponential(scale=12), 1)
    last_promotion_years = round(min(np.random.exponential(scale=2.2), tenure_years), 1)
    training_hours_year = int(np.clip(np.random.normal(20, 10), 0, 60))

    # Attrition probability driven by realistic-ish factors
    risk = 0.05
    risk += 0.18 if engagement_score < 50 else 0
    risk += 0.15 if overtime_hours_month > 15 else 0
    risk += 0.12 if perf_rating <= 2 else 0
    risk += 0.10 if last_promotion_years > 4 else 0
    risk += 0.08 if salary < base * 0.9 else 0
    risk += 0.07 if tenure_years < 1 else 0
    risk -= 0.05 if level in ["Lead", "Manager"] else 0
    risk = np.clip(risk, 0.02, 0.85)
    attrition = np.random.binomial(1, risk)

    rows.append({
        "EmployeeID": f"EMP{i:04d}",
        "Department": dept,
        "JobLevel": level,
        "Age": age,
        "Gender": gender,
        "Location": location,
        "Education": edu,
        "TenureYears": tenure_years,
        "Salary": int(salary),
        "PerformanceRating": perf_rating,
        "EngagementScore": engagement_score,
        "OvertimeHoursMonth": overtime_hours_month,
        "DistanceFromOfficeKm": distance_km,
        "YearsSinceLastPromotion": last_promotion_years,
        "TrainingHoursYear": training_hours_year,
        "Attrition": "Yes" if attrition == 1 else "No",
    })

df = pd.DataFrame(rows)
df.to_excel("sample_hr_data.xlsx", index=False)
print(f"Created sample_hr_data.xlsx with {len(df)} employees")
print(f"Attrition rate: {(df['Attrition'] == 'Yes').mean():.1%}")
